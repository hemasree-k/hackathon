# SkillChain Frontend

A simple React prototype showing:
- Homepage (introduction + how it works)
- Dashboard (tokens, skills, progress)

## Run
```bash
npm install
npm start
```
